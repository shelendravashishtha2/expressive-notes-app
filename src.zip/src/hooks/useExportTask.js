import { useCallback, useEffect, useRef, useState } from 'react';
import { exportPreparedPlanToPdf } from '../utils/pdf.js';
import { prepareExportPlanWithWorkers } from '../utils/exportPreparation.js';

const initialTaskState = {
  status: 'idle',
  stage: 'Idle',
  progress: 0,
  error: '',
  request: null,
  filename: ''
};

function createAbortError() {
  return new DOMException('Export cancelled by user.', 'AbortError');
}

async function waitForFrame(count = 1) {
  for (let index = 0; index < count; index += 1) {
    await new Promise((resolve) => window.requestAnimationFrame(resolve));
  }
}

export function useExportTask() {
  const controllerRef = useRef(null);
  const [task, setTask] = useState(initialTaskState);

  const startExport = useCallback((request) => {
    setTask({
      status: 'queued',
      stage: 'Preparing selection',
      progress: 4,
      error: '',
      request,
      filename: request?.filename || 'notes.pdf'
    });
  }, []);

  const cancelExport = useCallback(() => {
    controllerRef.current?.abort();
  }, []);

  const resetTask = useCallback(() => {
    controllerRef.current = null;
    setTask(initialTaskState);
  }, []);

  useEffect(() => {
    if (task.status !== 'queued' || !task.request) return undefined;

    let disposed = false;
    const controller = new AbortController();
    controllerRef.current = controller;

    const run = async () => {
      try {
        setTask((current) => ({
          ...current,
          status: 'mounting',
          stage: 'Spawning export workers',
          progress: 8
        }));

        await waitForFrame(1);
        if (controller.signal.aborted) throw createAbortError();

        const preparedPlan = await prepareExportPlanWithWorkers(task.request.plan, {
          signal: controller.signal,
          onStage: (stage) => {
            if (disposed) return;
            setTask((current) => ({ ...current, stage }));
          },
          onProgress: (progress) => {
            if (disposed) return;
            setTask((current) => ({ ...current, progress: Math.max(current.progress, progress) }));
          }
        });

        setTask((current) => ({
          ...current,
          status: 'exporting',
          stage: 'Creating PDF',
          progress: 44
        }));

        await exportPreparedPlanToPdf(preparedPlan, task.filename, {
          generatedAt: task.request.generatedAt,
          signal: controller.signal,
          onStage: (stage) => {
            if (disposed) return;
            setTask((current) => ({ ...current, stage }));
          },
          onProgress: (progress) => {
            if (disposed) return;
            setTask((current) => ({ ...current, progress: Math.max(current.progress, progress) }));
          }
        });

        if (disposed) return;
        setTask((current) => ({
          ...current,
          status: 'completed',
          stage: 'Completed',
          progress: 100,
          error: '',
          request: null
        }));
        controllerRef.current = null;
      } catch (error) {
        if (disposed) return;
        const aborted = controller.signal.aborted || error?.name === 'AbortError';
        setTask((current) => ({
          ...current,
          status: aborted ? 'cancelled' : 'error',
          stage: aborted ? 'Cancelled' : 'Export failed',
          progress: aborted ? 0 : current.progress,
          error: aborted ? '' : (error?.message || 'Unable to generate the PDF.'),
          request: null
        }));
        controllerRef.current = null;
      }
    };

    run();

    return () => {
      disposed = true;
      if (controllerRef.current === controller) {
        controllerRef.current = null;
      }
    };
  }, [task.filename, task.request, task.status]);

  return {
    task,
    startExport,
    cancelExport,
    resetTask
  };
}
