import { useEffect, useRef, useState } from "react";

const FALLBACK_ACCENT = { r: 124, g: 58, b: 237 };

/**
 * SectionBlobLoader
 *
 * Enhanced fluid canvas animation:
 * – Luminous Y-depth colorization (bright at the surface, rich at depth)
 * – Varied-size bubbles with multi-stop radial glow
 * – Sweeping shimmer highlight across the liquid surface
 * – Micro-sparkle particles that flicker at the meniscus
 */
export function SectionBlobLoader({
  loading = true,
  color = "var(--accent)",
  className = "",
}) {
  const canvasRef = useRef(null);
  const rafRef = useRef(null);
  const startRef = useRef(null);
  const visibleRef = useRef(true);
  const [phase, setPhase] = useState(loading ? "active" : "idle");
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (loading) setPhase("active");
    else if (phase === "active") setPhase("fading");
  }, [loading, phase]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const host = canvas?.parentElement;
    if (!canvas || !host || typeof IntersectionObserver === "undefined")
      return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        const isVisible = entries.some((entry) => entry.isIntersecting);
        visibleRef.current = isVisible;
        setVisible(isVisible);
      },
      {
        root: null,
        rootMargin: "260px 0px 320px 0px",
        threshold: 0.01,
      },
    );

    observer.observe(host);
    return () => observer.disconnect();
  }, [phase]);

  useEffect(() => {
    if (phase !== "active" || !visible) return undefined;

    const canvas = canvasRef.current;
    const host = canvas?.parentElement;
    if (!canvas || !host) return undefined;

    const W = Math.max(220, Math.floor(host.offsetWidth || 300));
    const H = Math.max(110, Math.floor(host.offsetHeight || 160));
    canvas.width = W;
    canvas.height = H;

    const ctx = canvas.getContext("2d", {
      willReadFrequently: true,
      alpha: true,
    });
    if (!ctx) return undefined;

    const off =
      typeof OffscreenCanvas !== "undefined"
        ? new OffscreenCanvas(W, H)
        : document.createElement("canvas");
    off.width = W;
    off.height = H;
    const oCtx = off.getContext("2d", {
      willReadFrequently: true,
      alpha: true,
    });
    if (!oCtx) return undefined;

    const rgb = resolveColorToRgb(color, host);
    const fillC = `rgb(${rgb.r},${rgb.g},${rgb.b})`;

    // Brightened surface color for the highlight shimmer and sparkles
    const bR = Math.min(255, rgb.r + 58);
    const bG = Math.min(255, rgb.g + 58);
    const bB = Math.min(255, rgb.b + 58);

    // 32 perturbation waves → richer, more organic surface
    const PERTURB = 32;
    const perturbs = Array.from({ length: PERTURB }, () => ({
      cx: Math.random() * W,
      width: W * (0.025 + Math.random() * 0.085),
      amp: 3 + Math.random() * 13,
      phase: Math.random() * Math.PI * 2,
      freq: 0.5 + Math.random() * 2.2,
      drift: (Math.random() - 0.5) * 17,
      amp2: 1.5 + Math.random() * 7,
      freq2: 1.0 + Math.random() * 3.0,
      phase2: Math.random() * Math.PI * 2,
    }));

    // 48 bubbles with varied radii for visual depth
    const COUNT = 48;
    const blobs = Array.from({ length: COUNT }, () => {
      const r = 7 + Math.random() * 14;
      return {
        offsetY: -(Math.random() * r * 2),
        x: Math.random() * W,
        xPhase: Math.random() * Math.PI * 2,
        xFreq: 0.7 + Math.random() * 2.6,
        xAmp: 5 + Math.random() * 22,
        speed: 0.45 + Math.random() * 1.5,
        delay: Math.random() * 0.55,
        r,
      };
    });

    // 14 surface sparkles that flicker in and out
    const SPARKLE_COUNT = 14;
    const sparkles = Array.from({ length: SPARKLE_COUNT }, () => ({
      x: Math.random() * W,
      xPhase: Math.random() * Math.PI * 2,
      xFreq: 0.3 + Math.random() * 1.1,
      xAmp: 10 + Math.random() * 32,
      phase: Math.random() * Math.PI * 2,
      freq: 0.6 + Math.random() * 1.8,
      life: Math.random(),
      lifeSpeed: 0.3 + Math.random() * 0.9,
      size: 1.2 + Math.random() * 2.8,
    }));

    function surfaceY(x, elapsed, baseFillY) {
      let offset = 0;
      for (let i = 0; i < PERTURB; i += 1) {
        const p = perturbs[i];
        const cx = (p.cx + elapsed * p.drift + W * 10) % W;
        const dx = Math.min(Math.abs(x - cx), W - Math.abs(x - cx));
        const gaussian = Math.exp(-(dx * dx) / (2 * p.width * p.width));
        const h1 = p.amp * Math.sin(elapsed * p.freq + p.phase);
        const h2 = p.amp2 * Math.sin(elapsed * p.freq2 + p.phase2);
        offset -= gaussian * Math.max(0, h1 + h2);
      }
      return baseFillY + offset;
    }

    let stopped = false;
    startRef.current = performance.now();

    function tick(now) {
      if (stopped) return;
      if (!visibleRef.current) {
        rafRef.current = window.requestAnimationFrame(tick);
        return;
      }

      const elapsed = (now - startRef.current) / 1000;
      // Smooth decelerated fill: fast early, then slows to final level
      const fillProgress = Math.min(elapsed * 0.22, 1);
      const eased = 1 - Math.pow(1 - fillProgress, 2.8);
      const baseFillY = H - H * eased;
      const entropy = Math.min(elapsed / 9, 1);

      oCtx.clearRect(0, 0, W, H);

      // ── Main liquid body ──────────────────────────────────────────
      oCtx.beginPath();
      oCtx.moveTo(0, H);
      for (let x = 0; x <= W; x += 1) {
        oCtx.lineTo(x, surfaceY(x, elapsed, baseFillY));
      }
      oCtx.lineTo(W, H);
      oCtx.closePath();
      oCtx.fillStyle = fillC;
      oCtx.fill();

      // ── Bubbles with luminous multi-stop glow ─────────────────────
      blobs.forEach((b) => {
        const t = Math.max(0, elapsed - b.delay);
        if (t <= 0) return;

        b.offsetY -= b.speed * (48 + entropy * 125) * (1 / 60);

        const wobble =
          Math.sin(elapsed * b.xFreq + b.xPhase) *
          b.xAmp *
          (0.35 + entropy * 2.1);
        const jitter = (Math.random() - 0.5) * entropy * 7;
        const cx = b.x + wobble + jitter;
        const cy = surfaceY(((cx % W) + W) % W, elapsed, baseFillY) + b.offsetY;
        const R = b.r;

        if (b.offsetY < -(H * 0.72)) {
          b.offsetY = R * 0.5 + Math.random() * R;
          b.x = Math.random() * W;
        }

        const grd = oCtx.createRadialGradient(cx, cy, 0, cx, cy, R * 2.1);
        grd.addColorStop(0, `rgba(${bR},${bG},${bB},0.95)`);
        grd.addColorStop(0.3, `rgba(${rgb.r},${rgb.g},${rgb.b},0.9)`);
        grd.addColorStop(0.65, `rgba(${rgb.r},${rgb.g},${rgb.b},0.4)`);
        grd.addColorStop(1, `rgba(${rgb.r},${rgb.g},${rgb.b},0)`);
        oCtx.beginPath();
        oCtx.arc(cx, cy, R * 2.1, 0, Math.PI * 2);
        oCtx.fillStyle = grd;
        oCtx.fill();
      });

      // ── Metaball threshold + Y-depth colorization ─────────────────
      const img = oCtx.getImageData(0, 0, W, H);
      const d = img.data;
      for (let p = 0; p < d.length; p += 4) {
        if (d[p + 3] < 128) {
          d[p + 3] = 0;
        } else {
          // Pixel is inside a blob or the liquid body — colorize with depth gradient
          const row = Math.floor(p / 4 / W);
          const depthFactor = Math.max(
            0,
            Math.min(1, (row - baseFillY) / Math.max(1, H - baseFillY)),
          );
          const brightBlend = Math.max(0, 1 - depthFactor * 3.5);
          d[p] = Math.round(rgb.r + (bR - rgb.r) * brightBlend * 0.55);
          d[p + 1] = Math.round(rgb.g + (bG - rgb.g) * brightBlend * 0.55);
          d[p + 2] = Math.round(rgb.b + (bB - rgb.b) * brightBlend * 0.55);
          d[p + 3] = 255;
        }
      }
      oCtx.putImageData(img, 0, 0);

      // ── Sweeping surface shimmer highlight ────────────────────────
      const shimPos = ((elapsed * 0.18) % 1.3) - 0.15;
      if (shimPos > -0.12 && shimPos < 1.12) {
        oCtx.beginPath();
        oCtx.moveTo(0, surfaceY(0, elapsed, baseFillY));
        for (let x = 1; x <= W; x += 1) {
          oCtx.lineTo(x, surfaceY(x, elapsed, baseFillY));
        }
        const shimGrad = oCtx.createLinearGradient(0, 0, W, 0);
        shimGrad.addColorStop(
          Math.max(0, shimPos - 0.16),
          `rgba(${bR},${bG},${bB},0)`,
        );
        shimGrad.addColorStop(shimPos, `rgba(${bR},${bG},${bB},0.65)`);
        shimGrad.addColorStop(
          Math.min(1, shimPos + 0.1),
          `rgba(${bR},${bG},${bB},0.2)`,
        );
        shimGrad.addColorStop(
          Math.min(1, shimPos + 0.22),
          `rgba(${bR},${bG},${bB},0)`,
        );
        oCtx.strokeStyle = shimGrad;
        oCtx.lineWidth = 2.5;
        oCtx.stroke();
      }

      // ── Surface sparkles ──────────────────────────────────────────
      sparkles.forEach((sp) => {
        sp.life += sp.lifeSpeed * (1 / 60);
        if (sp.life > 1) sp.life = 0;
        const alpha = Math.sin(sp.life * Math.PI);
        if (alpha < 0.05) return;
        const sx =
          (((sp.x + Math.sin(elapsed * sp.xFreq + sp.xPhase) * sp.xAmp) % W) +
            W) %
          W;
        const sy =
          surfaceY(sx, elapsed, baseFillY) +
          Math.sin(elapsed * sp.freq + sp.phase) * 2.5;
        oCtx.beginPath();
        oCtx.arc(sx, sy, sp.size, 0, Math.PI * 2);
        oCtx.fillStyle = `rgba(${bR},${bG},${bB},${alpha * 0.85})`;
        oCtx.fill();
      });

      ctx.clearRect(0, 0, W, H);
      ctx.drawImage(off, 0, 0);

      rafRef.current = window.requestAnimationFrame(tick);
    }

    rafRef.current = window.requestAnimationFrame(tick);

    return () => {
      stopped = true;
      if (rafRef.current) window.cancelAnimationFrame(rafRef.current);
    };
  }, [color, phase, visible]);

  useEffect(() => {
    if (phase !== "fading") return undefined;
    if (rafRef.current) window.cancelAnimationFrame(rafRef.current);

    const canvas = canvasRef.current;
    const host = canvas?.parentElement;
    if (canvas && host) {
      const W = Math.max(220, Math.floor(host.offsetWidth || 300));
      const H = Math.max(110, Math.floor(host.offsetHeight || 160));
      canvas.width = W;
      canvas.height = H;
      const ctx = canvas.getContext("2d");
      const rgb = resolveColorToRgb(color, host);
      if (ctx) {
        ctx.clearRect(0, 0, W, H);
        ctx.fillStyle = `rgb(${rgb.r},${rgb.g},${rgb.b})`;
        ctx.fillRect(0, 0, W, H);
      }
    }

    const timer = window.setTimeout(() => setPhase("idle"), 520);
    return () => window.clearTimeout(timer);
  }, [color, phase]);

  if (phase === "idle") return null;

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={`section-blob-loader ${phase === "fading" ? "is-fading" : ""} ${className}`.trim()}
    />
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Spinner atom
// ─────────────────────────────────────────────────────────────────────────────
function LoaderSpinner() {
  return <span className="inline-loader-spinner" aria-hidden="true" />;
}

// ─────────────────────────────────────────────────────────────────────────────
// InlineContentLoader  —  in-page loading placeholder
// ─────────────────────────────────────────────────────────────────────────────
export function InlineContentLoader({
  message = "Loading...",
  minHeight = "260px",
  className = "",
}) {
  return (
    <section
      className={`inline-content-loader ${className}`.trim()}
      style={{ minHeight }}
      role="status"
      aria-live="polite"
    >
      {/* Blob canvas with frosted-glass fade at edges */}
      <div className="bubbly-loader-visual">
        <SectionBlobLoader color="var(--accent)" />
        <div className="bubbly-loader-glass" aria-hidden="true" />
      </div>

      {/* Animated skeleton text bars */}
      <div className="inline-skeleton-bars" aria-hidden="true">
        <div className="inline-skeleton-bar" style={{ width: "87%" }} />
        <div className="inline-skeleton-bar" style={{ width: "71%" }} />
        <div className="inline-skeleton-bar" style={{ width: "94%" }} />
        <div className="inline-skeleton-bar" style={{ width: "56%" }} />
      </div>

      {/* Status copy */}
      <div className="inline-loader-copy">
        <LoaderSpinner />
        <span>{message}</span>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// AppStartupLoader  —  full-screen launch screen
// ─────────────────────────────────────────────────────────────────────────────
export function AppStartupLoader({ message = "Loading..." }) {
  const text = message || "Loading...";

  return (
    <main
      className="startup-loader"
      role="status"
      aria-live="polite"
      aria-busy="true"
    >
      {/* Three ambient aurora drift bands */}
      <div className="startup-aurora" aria-hidden="true">
        <div className="startup-aurora-band startup-aurora-band--1" />
        <div className="startup-aurora-band startup-aurora-band--2" />
        <div className="startup-aurora-band startup-aurora-band--3" />
      </div>

      {/* Central glass card */}
      <div className="startup-crystal-card">
        {/* Glowing orb: halo → ring → core */}
        <div className="startup-orb-cluster" aria-hidden="true">
          <div className="startup-orb-halo" />
          <div className="startup-orb-ring" />
          <div className="startup-orb-core" />
        </div>

        {/* Status text + spinner */}
        <div className="startup-loader-copy">
          <LoaderSpinner />
          <span>{text}</span>
        </div>

        {/* Sweeping progress track */}
        <div className="startup-progress-track" aria-hidden="true">
          <div className="startup-progress-fill" />
        </div>
      </div>

      {/* Liquid blob band at the foot of the screen */}
      <div className="startup-loader-band" aria-hidden="true">
        <SectionBlobLoader color="var(--accent)" />
      </div>
    </main>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SyncStatusDock  —  fixed bottom-right dock
// ─────────────────────────────────────────────────────────────────────────────
export function SyncStatusDock({ show, status = "syncing", message }) {
  if (!show) return null;
  const text =
    message ||
    (status === "error"
      ? "Remote notes are waking up"
      : "Streaming latest notes from backend");

  return (
    <div
      className={`sync-status-dock ${status === "error" ? "is-error" : ""}`}
      role="status"
      aria-live="polite"
    >
      <span className="sync-status-pulse" />
      <span>{text}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Convenience re-exports
// ─────────────────────────────────────────────────────────────────────────────
export function InlineTopicLoader({
  message = "Loading...",
  minHeight = "320px",
}) {
  return <InlineContentLoader message={message} minHeight={minHeight} />;
}

export function FullScrollTailLoader() {
  return (
    <InlineContentLoader
      message="Loading..."
      minHeight="220px"
      className="my-10"
    />
  );
}

// Backward-compatible default export for old imports
export default function BlobLoader({
  loading = false,
  color = "var(--accent)",
  children,
  className = "",
  style = {},
}) {
  return (
    <div className={`blob-loader-host ${className}`.trim()} style={style}>
      {children}
      {loading ? (
        <div className="bubbly-loader-visual blob-loader-overlay-visual">
          <SectionBlobLoader color={color} />
        </div>
      ) : null}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Color resolution helpers (unchanged)
// ─────────────────────────────────────────────────────────────────────────────
function resolveColorToRgb(color, element) {
  if (!color || typeof color !== "string") return FALLBACK_ACCENT;

  const trimmed = color.trim();
  if (trimmed.startsWith("var(") && element) {
    const variableName = trimmed.match(/var\((--[^),\s]+)/)?.[1];
    if (variableName) {
      return resolveColorToRgb(
        getComputedStyle(element).getPropertyValue(variableName).trim(),
        element,
      );
    }
  }

  if (trimmed.startsWith("#")) return hexToRgb(trimmed);

  const rgbMatch = trimmed.match(/rgba?\(([^)]+)\)/i);
  if (rgbMatch) {
    const [r, g, b] = rgbMatch[1]
      .split(",")
      .map((part) => Number.parseFloat(part.trim()));
    if ([r, g, b].every(Number.isFinite)) {
      return { r: Math.round(r), g: Math.round(g), b: Math.round(b) };
    }
  }

  if (element && typeof document !== "undefined") {
    const probe = document.createElement("span");
    probe.style.color = trimmed;
    probe.style.position = "absolute";
    probe.style.pointerEvents = "none";
    probe.style.opacity = "0";
    element.appendChild(probe);
    const resolved = getComputedStyle(probe).color;
    probe.remove();
    if (resolved && resolved !== trimmed)
      return resolveColorToRgb(resolved, element);
  }

  return FALLBACK_ACCENT;
}

function hexToRgb(hex) {
  const clean = hex.replace("#", "").trim();
  const full =
    clean.length === 3
      ? clean
          .split("")
          .map((char) => char + char)
          .join("")
      : clean;
  const int = Number.parseInt(full, 16);
  if (!Number.isFinite(int)) return FALLBACK_ACCENT;
  return {
    r: (int >> 16) & 255,
    g: (int >> 8) & 255,
    b: int & 255,
  };
}
